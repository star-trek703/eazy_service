const PageNotFound = () => {
    return (
        <div>
            <h1 style={{ textAlign: 'center' }}>
                404 <br />
                Page Not found
            </h1>
        </div>
    )
}

export default PageNotFound
