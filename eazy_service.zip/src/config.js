const APP_URL = "https://eazyservice.co.in"
const API_URL = APP_URL +"/app_apis/"

export { APP_URL, API_URL }
